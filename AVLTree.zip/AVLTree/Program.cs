﻿using System;

class Nodo
{
    public int valor;
    public Nodo? izquierda, derecha; // ← permite null
    public int altura;

    public Nodo(int valor)
    {
        this.valor = valor;
        altura = 1;
    }
}

class AVL
{
    // Obtener altura
    int Altura(Nodo? n)
    {
        return n == null ? 0 : n.altura;
    }

    // Obtener factor de balance
    int Balance(Nodo? n)
    {
        return n == null ? 0 : Altura(n.izquierda) - Altura(n.derecha);
    }

    // Rotación derecha
    Nodo RotarDerecha(Nodo y)
    {
        Nodo x = y.izquierda!;
        Nodo? T2 = x.derecha;

        x.derecha = y;
        y.izquierda = T2;

        y.altura = Math.Max(Altura(y.izquierda), Altura(y.derecha)) + 1;
        x.altura = Math.Max(Altura(x.izquierda), Altura(x.derecha)) + 1;

        return x;
    }

    // Rotación izquierda
    Nodo RotarIzquierda(Nodo x)
    {
        Nodo y = x.derecha!;
        Nodo? T2 = y.izquierda;

        y.izquierda = x;
        x.derecha = T2;

        x.altura = Math.Max(Altura(x.izquierda), Altura(x.derecha)) + 1;
        y.altura = Math.Max(Altura(y.izquierda), Altura(y.derecha)) + 1;

        return y;
    }

    // Insertar nodo
    public Nodo Insertar(Nodo? nodo, int valor)
    {
        if (nodo == null)
            return new Nodo(valor);

        if (valor < nodo.valor)
            nodo.izquierda = Insertar(nodo.izquierda, valor);
        else if (valor > nodo.valor)
            nodo.derecha = Insertar(nodo.derecha, valor);
        else
            return nodo;

        nodo.altura = 1 + Math.Max(Altura(nodo.izquierda), Altura(nodo.derecha));

        int balance = Balance(nodo);

        // LL
        if (balance > 1 && valor < nodo.izquierda!.valor)
            return RotarDerecha(nodo);

        // RR
        if (balance < -1 && valor > nodo.derecha!.valor)
            return RotarIzquierda(nodo);

        // LR
        if (balance > 1 && valor > nodo.izquierda!.valor)
        {
            nodo.izquierda = RotarIzquierda(nodo.izquierda!);
            return RotarDerecha(nodo);
        }

        // RL
        if (balance < -1 && valor < nodo.derecha!.valor)
        {
            nodo.derecha = RotarDerecha(nodo.derecha!);
            return RotarIzquierda(nodo);
        }

        return nodo;
    }

    // Recorrido PreOrden
    public void PreOrden(Nodo? nodo)
    {
        if (nodo != null)
        {
            Console.Write(nodo.valor + " ");
            PreOrden(nodo.izquierda);
            PreOrden(nodo.derecha);
        }
    }
}

class Program
{
    static void Main()
    {
        AVL arbol = new AVL();
        Nodo? raiz = null;

        raiz = arbol.Insertar(raiz, 30);
        raiz = arbol.Insertar(raiz, 20);
        raiz = arbol.Insertar(raiz, 10);

        Console.WriteLine("Recorrido PreOrden:");
        arbol.PreOrden(raiz);
    }
}